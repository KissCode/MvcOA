
Some internal fields/methods are made "public" to be able to use them in Test project. 
Those fields/methods (starting with a lowercase char) are not intended to be used in your code.

Rev:916090 25Feb2010

java source: https://svn.apache.org/repos/asf/lucene/java/trunk/contrib/fast-vector-highlighter
