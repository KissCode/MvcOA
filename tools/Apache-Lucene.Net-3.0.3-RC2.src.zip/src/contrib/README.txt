This folder contains both ported and contributed code to the Lucene.Net project.  The ported code are those from the Java to C# while the contributed code are new work which don't necessarily exist in the Java side of Lucene.  

Ported code:
------------

Highlighter
Snowball
SpellChecker
WordNet
Similarity (obsolete. Use Queries)
Analyzers\BR
Spatial
FastVectorHighlighter
Queries


Contributed code:
-----------------

DistributedSearch