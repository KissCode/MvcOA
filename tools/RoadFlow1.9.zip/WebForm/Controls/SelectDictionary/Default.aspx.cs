﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebForm.Controls.SelectDictionary
{
    public partial class Default : Common.BasePage
    {
        protected string defaultValuesString = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            RoadFlow.Platform.Dictionary Dict = new RoadFlow.Platform.Dictionary();

            string values = Request.QueryString["values"];
            string rootid = Request.QueryString["rootid"];

            System.Text.StringBuilder defautlSB = new System.Text.StringBuilder();
            foreach (string value in values.Split(','))
            {
                Guid id;
                if (!value.IsGuid(out id))
                {
                    continue;
                }
                defautlSB.AppendFormat("<div onclick=\"currentDel=this;showinfo('{0}');\" class=\"selectorDiv\" ondblclick=\"currentDel=this;del();\" value=\"{0}\">", value);
                defautlSB.Append(Dict.GetTitle(id));
                defautlSB.Append("</div>");
            }
            defaultValuesString = defautlSB.ToString();
        }

        protected override bool CheckApp()
        {
            return true;//base.CheckApp();
        }
    }
}